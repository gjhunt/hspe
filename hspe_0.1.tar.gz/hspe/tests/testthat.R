library(testthat)

test_check("hspe")
